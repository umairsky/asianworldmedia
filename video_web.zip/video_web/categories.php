<?php
error_reporting(0);
session_start();
include('connection/config.php');
$cat = $_GET['cat'];
$id  = $_GET['id'];

$_SESSION['cat'] = $cat;
$_SESSION['idd'] = $sub_cat;
?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories video</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="layerslider/css/layerslider.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery.kyco.easyshare.css">
    <link rel="stylesheet" href="css/responsive.css">
    <style>.page-next{background:#fff;color:#FF8080;padding:20px 0 20px 0;font-size: 13px;	text-align:center;}
.page-next a{border:1px solid #BBC0BE;padding:5px 10px;margin:0px 0px 0px 8px;color: #000;text-decoration:none; font:12px Arial, Helvetica, sans-serif;}
.page-next a:hover{background-color:#000;color:#fff;}
.page-next a.active{background-color:#FF8080;color:#fff;}</style>

</head>
<body>
<div class="off-canvas-wrapper">
    <div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
        <!--header-->
        
        <div class="off-canvas-content" data-off-canvas-content>
            <?php include('header.php');?><!-- End Header -->
            <!--breadcrumbs-->
            <section id="breadcrumb">
                <div class="row">
                    <div class="large-12 columns">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs">
                                <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
                                <li>
                                    <span class="show-for-sr">Current: </span> categories
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </section><!--end breadcrumbs-->
            <!-- Premium Videos -->
            <!-- End Premium Videos -->
            <section class="category-content">
                <div class="row">
                    <!-- left side content area -->
                    <div class="large-8 columns">
                        <section class="content content-with-sidebar">
                            <!-- newest video -->
                            <div class="main-heading removeMargin">
                                 <div class="row secBg padding-14 removeBorderBottom">
                                    <div class="medium-8 small-8 columns">
                                        <div class="head-title">
                                            <i class="fa fa-film"></i>
                                            <h4><?php if(isset($cat)){ echo $cat; } else { echo $_GET['id']; }?></h4>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="row secBg">
                                <div class="large-12 columns">
                                    <div class="row column head-text clearfix">
                                    
                                        <p class="pull-left">All Videos : <span>
										<?php 
										if(isset($cat))
										{
										 $query1 = mysqli_query($link,"select * from video_post where category = '$cat'");
										}
										else
										{
											$query1 = mysqli_query($link,"select * from video_post where sub_category = '$id'");
										}
										
										$num_rows = mysqli_num_rows($query1)
										
										
										?><?php echo $num_rows;  ?> Videos posted</span></p>
                                        
                                    </div>
                                    <div class="tabs-content" data-tabs-content="newVideos">
                                        <div class="tabs-panel is-active" id="new-all">
                                            <div class="row list-group">
                                            <?php 
											 $i = 0;
  $page = $_GET['page'];
  
		   //////////////////// Pagination Code Start//////////////////////
   
	$tbl_name="video_post";
	$adjacents = 2;
	
	if(isset($cat))
	{
	
	$query = mysqli_query($link,"SELECT COUNT(*) as num FROM $tbl_name where id!='' and category='$cat' order by id desc");
	
	
	$total_pages = mysqli_fetch_array($query);
	$total_pages = $total_pages[num];
	
	$targetpage = "categories.php";
	$limit =6; 							
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 	
	else
		$start = 0;					
	
	
	$pageresult = mysqli_query($link,"SELECT * FROM $tbl_name where id!='' and category='$cat' order by id desc LIMIT $start, $limit");
	
	
	//$pageresult = mysqli_query($sql);
	
	if ($page == 0) $page = 1;					
	$prev = $page - 1;						
	$next = $page + 1;							
	$lastpage = ceil($total_pages/$limit);		
	$lpm1 = $lastpage - 1;			
	
	$pagination = "";
	if($lastpage > 1)
	{	
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$prev\"> Prev </a>";
		else
			$pagination.= " <a href=\"#\"> Prev </a>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
				else
					$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$counter\"> $counter </a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$counter\"> $counter </a>";					
				}
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=$lpm1\"> $lpm1 </a>";
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=$lastpage\"> $lastpage </a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=2\">2</a>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$counter\"> $counter </a>";					
				}
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=$lpm1\"> $lpm1 </a>";
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=$lastpage\"> $lastpage< /a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage?cat=$cat&cat=$cat&page=1\"> 1 </a>";
				$pagination.= "<a href=\"$targetpage?cat=$cat&page=2\"> 2 </a>";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$counter\"> $counter </a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage?cat=$cat&$anck&page=$next\"> Next  </a>";
		else
			$pagination.= "<a href=\"#\"> Next</a>";		
	}
	}
	else
	{
		$query = mysqli_query($link,"SELECT COUNT(*) as num FROM $tbl_name where id!='' and sub_category='$id' order by id desc");
	
	
	$total_pages = mysqli_fetch_array($query);
	$total_pages = $total_pages[num];
	
	$targetpage = "categories.php";
	$limit =6; 							
	$page = $_GET['page'];
	if($page) 
		$start = ($page - 1) * $limit; 	
	else
		$start = 0;					
	
	
	$pageresult = mysqli_query($link,"SELECT * FROM $tbl_name where id!='' and sub_category='$id' order by id desc LIMIT $start, $limit");
	
	
	//$pageresult = mysqli_query($sql);
	
	if ($page == 0) $page = 1;					
	$prev = $page - 1;						
	$next = $page + 1;							
	$lastpage = ceil($total_pages/$limit);		
	$lpm1 = $lastpage - 1;			
	
	$pagination = "";
	if($lastpage > 1)
	{	
		if ($page > 1) 
			$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$prev\"> Prev </a>";
		else
			$pagination.= " <a href=\"#\"> Prev </a>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
				else
					$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$counter\"> $counter </a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$counter\"> $counter </a>";					
				}
				$pagination.= "<a href=\"$targetpage?id=$id&page=$lpm1\"> $lpm1 </a>";
				$pagination.= "<a href=\"$targetpage?id=$id&page=$lastpage\"> $lastpage </a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"$targetpage?id=$id&page=1\">1</a>";
				$pagination.= "<a href=\"$targetpage?id=$id&page=2\">2</a>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$counter\"> $counter </a>";					
				}
				$pagination.= "<a href=\"$targetpage?id=$id&page=$lpm1\"> $lpm1 </a>";
				$pagination.= "<a href=\"$targetpage?id=$id&page=$lastpage\"> $lastpage< /a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"$targetpage?id=$id&cat=$cat&page=1\"> 1 </a>";
				$pagination.= "<a href=\"$targetpage?id=$id&page=2\"> 2 </a>";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<a href=\"\" class=\"active\"> $counter </a>";
					else
						$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$counter\"> $counter </a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"$targetpage?id=$id&$anck&page=$next\"> Next  </a>";
		else
			$pagination.= "<a href=\"#\"> Next</a>";		
	}
	}
													while($rrow=mysqli_fetch_array($pageresult))
													{
													
													?>
                                                <div class="item large-4 medium-6 columns grid-medium">
                                                    <div class="post thumb-border">
                                                    
                                                        <div class="post-thumb">
                                                            <img src="http://img.youtube.com/vi/<?php echo $rrow['video_url'];?>/0.jpg" alt="new video">
                                                            <a href="single-video-v2.php?video_url=<?php echo $rrow['video_url']?>" class="hover-posts">
                                                                <span><i class="fa fa-play"></i>Watch Video</span>
                                                            </a>
                                                            <div class="video-stats clearfix">
                                                                <div class="thumb-stats pull-left">
                                                                    <h6>HD</h6>
                                                                </div>
                                                                <div class="thumb-stats pull-left">
                                                                    <i class="fa fa-heart"></i>
                                                                    <span>506</span>
                                                                </div>
                                                                <div class="thumb-stats pull-right">
                                                                    <span>05:56</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="post-des">
                                                            <h6><a href="single-video-v2.html"><?php echo $rrow['title']?></a></h6>
                                                            <div class="post-stats clearfix">
                                                                
                                                                <p class="pull-left">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    <?php 
																	
																	$date=date_create("$rrow[date]");
													 				$fin = date_format($date,"d F Y");
													 ?>
                                                                    <span><?php echo $fin?></span>
                                                                </p>
                                                                <p class="pull-left">
                                                                    <i class="fa fa-eye"></i>
                                                                    <span>1,862K</span>
                                                                </p>
                                                            </div>
                                                            <div class="post-summary">
                                                                <p><?php echo $rrow['description']?></p>
                                                            </div>
                                                            <div class="post-button">
                                                                <a href="single-video-v2.html" class="secondary-button"><i class="fa fa-play-circle"></i>watch video</a>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                
                                                <?php } ?>
                                            </div>
                                        </div>
                                        
                                    </div>
                                     
<div class="page-next"><div class="page-next"><?php  echo $pagination; ?></div> 
                                    </div>
                            </div>
                        </section>
                        <!-- ad Section -->
                        <!-- End ad Section -->
                    </div><!-- end left side content area -->
                    <!-- sidebar -->
                    <?php include('right_sidebar.php');?><!-- end sidebar -->
                </div>
            </section><!-- End Category Content-->
            <!-- footer -->
  <?php include('footer.php'); ?>