  <div class="off-canvas position-left light-off-menu" id="offCanvas-responsive" data-off-canvas>
            <div class="off-menu-close">
                <h3>Menu</h3>
                <span data-toggle="offCanvas-responsive"><i class="fa fa-times"></i></span>
            </div>
            <ul class="vertical menu off-menu" data-responsive-menu="drilldown">
                
                <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="#"><i class=""></i>Entertainment</a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                        <li><a href="categories.php?id=Nhan Goi Yeu Thuong (Musix Box)"><i class=""></i> NHAN GOI YEU THUƠNG (MUSIC BOX)</a></li>
                        <li><a href="categories.php?id=Cham Cham Cham (Dot Dot Dot)"><i class=""></i>CHAM CHAM CHAM (DOT DOT DOT)</a></li>
                        <li><a href="categories.php?id=Am Nhac Va Cuoc Song"><i class=""></i>AM NHẠC VA CUOC SONG</a></li>
                         <li><a href="categories.php?id=Music Liveshows"><i class=""></i> MUSIC LIVESHOWS</a></li>
                          <li><a href="categories.php?id=Nails Today Show"><i class=""></i>NAILS TODAY SHOW</a></li>
                         <li><a href="categories.php?id=Bo Ba Show"><i class=""></i>BO BA SHOW</a></li>
                         <li><a href="categories.php?id=Gentleman Life Style"><i class=""></i>GENTLEMEN LIFE STYLE</a></li>
                         <li><a href="categories.php?id=An Vat ( 50K a Night)"><i class=""></i>AN VAT (5OK A NIGHT)</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu" data-dropdown-menu="example1">
                    	<a href="categories.php?cat=Travels"><i class=""></i>Travel</a>
                   			 <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                                 <li><a href="categories.php?id=Thu Gian Cuoi Tuan"><i class=""></i>THU GIAN CUOI TUAN</a></li>
                                 <li><a href="categories.php?id=Viet Nam - Dat Nuoc Toi Yeu"><i class=""></i>VIET NAM - DET NUOC TOI YEU</a></li>
                                 <li><a href="categories.php?id=Di Day Di Do"><i class=""></i>DI DAT DI DO</a></li>
                             </ul>
                   </li>
                   <li class="has-submenu" data-dropdown-menu="example1">
                       <a href="categories.php?cat=Drama"><i class=""></i>Drama</a>
                         <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                       <li><a href="categories.php?id=Taiwanese"><i class=""></i>TAIWANESE</a></li>
                       <li><a href="categories.php?id=Thai"><i class=""></i>THAI</a></li>
                       <li><a href="categories.php?id=Thai"><i class=""></i>VIETNAMESE</a></li>
                       <li><a href="categories.php?id=chinese"><i class=""></i>CHINESE</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="categories.php?cat=Talk show"><i class=""></i>Talk show</a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                       <li><a href="categories.php?id=Suc Khoe va Cuoc Song"><i class=""></i>SUC KHOE VA CUOC SONG</a></li>
                       <li><a href="categories.php?id=Bi Quyet Tai Chinh (Financial Insight)"><i class=""></i>BI QUYET TAI CHINH (FINANCIAL INSIGHT)</a></li>
                       <li><a href="categories.php?id=Cuoc Song Hom Nay ( Mental Health)"><i class=""></i>CUOC SONG HOM NAY (MENTAL HEALTH)</a></li>
                       <li><a href="categories.php?id=American Dream"><i class=""></i>AMERICAN DREAM</a></li>
                    </ul>
                </li>
                <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="categories.php?cat=Game show"><i class=""></i>Game Show</a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                      <li><a href="categories.php?id=Giai Ma Cap Doi"><i class=""></i>GIAI MA CAP DOI</a></li>
                    </ul>
                </li>
                
            </ul>
            <div class="responsive-search">
                <form method="post">
                    <div class="input-group">
                        <input class="input-group-field" type="text" placeholder="Search the site">
                        <div class="input-group-button">
                            <button type="submit" name="search"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="off-social">
                <h6>Get Socialize</h6>
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-youtube"></i></a>
            </div>
            <div class="top-button">
                <ul class="menu">
                    
                    <li class="dropdown-login">
                        <a href="login.php">login/Register</a>
                    </li
                ></ul>
            </div>
        </div>
        <div class="off-canvas-content" data-off-canvas-content>
            <header>
                <!-- Top -->
                <!-- End Top -->
                <!--Navber-->
                <section id="navBar">
                    <nav class="sticky-container" data-sticky-container>
                        <div class="sticky topnav" data-sticky data-top-anchor="navBar" data-btm-anchor="footer-bottom:bottom" data-margin-top="0" data-margin-bottom="0" style="width: 100%; background: #fff;" data-sticky-on="large">
                            <div class="row">
                                <div class="large-12 columns">
                                    <div class="title-bar" data-responsive-toggle="beNav" data-hide-for="large">
                                        <button class="menu-icon" type="button" data-toggle="offCanvas-responsive"></button>
                                        <div class="title-bar-title"><a href="index.php" ><img src="images/logo.png" alt="logo" style="width:70%"></a></div>
                                    </div>

                                    <div class="top-bar show-for-large" id="beNav" style="width: 100%;">
                                        <div class="top-bar-left">
                                            <ul class="menu">
                                                <li class="menu-text">
                                                    <a href="index.php"><img src="images/logo.png" alt="logo"></a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="top-button">
                                <ul class="menu float-right">
                                    
                                    <li class="dropdown-login">
                                        <a class="loginReg" data-toggle="example-dropdown" href="#" style="padding:10px; margin-top:20px; margin-left:15px; color:#fff">login/Register</a>
                                        <div class="login-form">
                                            <h6 class="text-center">Great to have you back!</h6>
                                            <form method="post">
                                                <div class="input-group">
                                                    <span class="input-group-label"><i class="fa fa-user"></i></span>
                                                    <input class="input-group-field" type="text" placeholder="Enter username">
                                                </div>
                                                <div class="input-group">
                                                    <span class="input-group-label"><i class="fa fa-lock"></i></span>
                                                    <input class="input-group-field" type="text" placeholder="Enter password">
                                                </div>
                                                <div class="checkbox">
                                                    <input id="check1" type="checkbox" name="check" value="check">
                                                    <label class="customLabel" for="check1">Remember me</label>
                                                </div>
                                                <input type="submit" name="submit" value="Login Now">
                                            </form>
                                            <p class="text-center">New here? <a class="newaccount" href="login-register.php">Create a new Account</a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                                        <div class="top-bar-right search-btn">
                                            <ul class="menu">
                                                <li class="search">
                                                    <i class="fa fa-search"></i>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="top-bar-right">
                                            <ul class="menu vertical medium-horizontal" data-responsive-menu="drilldown medium-dropdown">
                                              <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="categories.php?cat=Entertaiment">Entertainment &nbsp;<i class="fa fa-caret-down"></i></a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                        <li><a href="categories.php?id=Nhan Goi Yeu Thuong (Musix Box)"><i class=""></i> NHẮN GỞI YÊU THƯƠNG (MUSIC BOX)</a></li>
                        <li><a href="categories.php?id=Cham Cham Cham (Dot Dot Dot)"><i class=""></i> CHẤM CHẤM CHẤM (DOT DOT DOT)</a></li>
                        <li><a href="categories.php?id=Am Nhac Va Cuoc Song"><i class=""></i>ÂM NHẠC VÀ CUỘC SỐNG</a></li>
                         <li><a href="categories.php?id=Music Liveshows"><i class=""></i> MUSIC LIVESHOWS</a></li>
                          <li><a href="categories.php?id=Nails Today Show"><i class=""></i>NAILS TODAY SHOW</a></li>
                         <li><a href="categories.php?id=Bo Ba Show"><i class=""></i> BỘ BA SHOW</a></li>
                         <li><a href="categories.php?id=Gentleman Life Style"><i class=""></i>GENTLEMEN LIFE STYLE</a></li>
                         <li><a href="categories.php?id=An Vat ( 50K a Night)"><i class=""></i>ĂN VẶT (5OK A NIGHT)</a></li>
                    </ul>
                </li>
                
                	<li class="has-submenu" data-dropdown-menu="example1">
                    	<a href="categories.php?cat=Travels">Travel &nbsp;<i class="fa fa-caret-down"></i></a>
                   			 <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                                 <li><a href="categories.php?id=Thu Gian Cuoi Tuan"><i class=""></i>THƯ GIÃN CUỐI TUẦN</a></li>
                                 <li><a href="categories.php?id=Viet Nam - Dat Nuoc Toi Yeu"><i class=""></i>VIỆT NAM - ĐẤT NƯỚC TÔI YÊU</a></li>
                                  <li><a href="categories.php?id=LIFE ON WHEELS"><i class=""></i>LIFE ON WHEELS</a></li>
                                 <li><a href="categories.php?id=Di Day Di Do"><i class=""></i> ĐI ĐÂY ĐI ĐÓ</a></li>
                             </ul>
                   </li>
             		 <li class="has-submenu" data-dropdown-menu="example1">
                       <a href="categories.php?cat=Drama">Drama &nbsp;<i class="fa fa-caret-down"></i></a>
                         <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                       <li><a href="categories.php?id=Taiwanese"><i class=""></i>TAIWANESE</a></li>
                       <li><a href="categories.php?id=Thai"><i class=""></i>THAI</a></li>
                       <li><a href="categories.php?id=Thai"><i class=""></i>VIETNAMESE</a></li>
                       <li><a href="categories.php?id=chinese"><i class=""></i>CHINESE</a></li>
                    </ul>
                </li>
                
                <li> <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="categories.php?cat=Talk show">Talk show &nbsp;<i class="fa fa-caret-down"></i></a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                       <li><a href="categories.php?id=Suc Khoe va Cuoc Song"><i class=""></i>SỨC KHOẺ VÀ CUỘC SỐNG</a></li>
                       <li><a href="categories.php?id=Bi Quyet Tai Chinh (Financial Insight)"><i class=""></i>BÍ QUYẾT TÀI CHÍNH (FINANCIAL INSIGHT)</a></li>
                       <li><a href="categories.php?id=Cuoc Song Hom Nay ( Mental Health)"><i class=""></i>CUỘC SỐNG HÔM NAY (MENTAL HEALTH)</a></li>
                       <li><a href="categories.php?id=American Dream"><i class=""></i>AMERICAN DREAM</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu" data-dropdown-menu="example1">
                    <a href="categories.php?cat=Game show">Game Show &nbsp;<i class="fa fa-caret-down"></i></a>
                    <ul class="submenu menu vertical" data-submenu data-animate="slide-in-down slide-out-up">
                      <li><a href="categories.php?id=Giai Ma Cap Doi"><i class=""></i>GIẢI MÃ CẶP ĐÔI</a></li>
                    </ul>
                </li>
                                                
                                                <div class="medium-6 columns">
                            <div class="top-button">
                                <ul class="menu float-right">
                                    
                                    
                                </ul>
                            </div>
                        </div>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="search-bar" class="clearfix search-bar-light">
                                <form method="post">
                                    <div class="search-input float-left">
                                        <input type="search" name="search" placeholder="Search the site">
                                    </div>
                                    <div class="search-btn float-right text-right">
                                        <button class="button" name="search" type="submit">search now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </nav>
                </section>
            </header><!-- End Header -->