<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asian_world";

// Create connection

$link = mysqli_connect($servername, $username, $password, $dbname);

// Check connection

if (!$link) 
{
    die("Connection failed: " . mysqli_connect_error());
}


date_default_timezone_set("Asia/Kolkata");

$datetime = date('d-m-Y H:i:s a');



?>