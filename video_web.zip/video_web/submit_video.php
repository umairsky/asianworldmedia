<?php
error_reporting(0);
session_start();
include('connection/config.php');


if($_REQUEST['submit'])
{ 


 
 $title = $_POST['title'];
 
 $description = $_POST['description'];
 
 $video_url = $_POST['video_url'];
 
 $meta_title = $_POST['meta_title'];
  
 $meta_desc = $_POST['meta_desc'];
 
 $meta_keyword	= $_POST['meta_keyword'];
 
 $category_main= $_POST['category_main'];
 
 $sub_category = $_POST['sub_category'];
 
  $time = time();
 $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
 $imgext = array('JPEG','JPG','PNG','BMP','GIF','jpeg','jpg','png','bmp','gif');
 
 	$img_name = $_FILES['image']['name'];
	$imagetmp = $_FILES['image']['tmp_name'];
	$imgg = $time.'.'.$ext;
	move_uploaded_file($imagetmp,"video_images/".$imgg);
 
 $query = mysqli_query($link,"INSERT INTO `video_post`( `title`, `description`, `video_url`, `meta_title`, `meta_desc`, `meta_keywords`, `category`,  `sub_category`,`image`,`date`) VALUES 
 ('$title','$description','$video_url','$meta_title','$meta_desc','$meta_keyword','$category_main','$sub_category','$imgg',now())");
 echo "<script>window.location='single-video-v2.php?msg=You have successfully uploaded With us&video_url=$video_url';</script>"; 
	
}



?> 