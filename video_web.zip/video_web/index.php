<?php 
error_reporting(0);
session_start();
include('connection/config.php');

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asian World Media</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="layerslider/css/layerslider.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<div class="off-canvas-wrapper">
    <div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
        <!--header-->
        
        <div class="off-canvas-content" data-off-canvas-content>
        <?php include('header.php');?>
      <!-- End Header -->
            <!-- layerslider -->
            <section id="slider">
                <div id="full-slider-wrapper">
                    <div id="layerslider" style="width:100%;height:500px;">
                        <div class="ls-slide" data-ls="transition2d:1;timeshift:-10000;">
                            <img src="images/sliderimages/banner1.png" class="ls-bg" alt="Slide background"/>
                            <h3 class="ls-l" style="left:50px; top:135px; padding: 15px; color: #444444;font-size: 24px;font-family: 'Open Sans'; font-weight: bold; text-transform: uppercase;" data-ls="offsetxin:0;durationin:2500;delayin:500;durationout:750;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotateout:-90;transformoriginout:left bottom 0;"></h3>
                            <h1 class="ls-l" style="left: 63px; top:185px;background: #e96969;padding:0 10px; opacity: 1; color: #ffffff; font-size: 36px; font-family: 'Open Sans'; text-transform: uppercase; font-weight: bold;" data-ls="offsetxin:left;durationin:3000; delayin:800;durationout:850;rotatexin:90;rotatexout:-90;"></h1>
                            <p class="ls-l" style="font-weight:600;left:62px; top:250px; opacity: 1;width: 450px; color: #444; font-size: 14px; font-family: 'Open Sans';" data-ls="offsetyin:top;durationin:4000;rotateyin:90;rotateyout:-90;durationout:1050;">.</p>
                            <!--<a href="#" class="ls-l button" style="border-radius:4px;text-align:center;left:63px; top:315px;background: #444;color: #ffffff;font-family: 'Open Sans';font-size: 14px;display: inline-block; text-transform: uppercase; font-weight: bold;" data-ls="durationout:850;offsetxin:90;offsetxout:-90;duration:4200;fadein:true;fadeout:true;">Upload Videos</a>-->
                            <img class="ls-l" src="" alt="" style="top:55px; left:700px;" data-ls="offsetxin:right;durationin:3000; delayin:600;durationout:850;rotatexin:-90;rotatexout:90;">
                            <img class="ls-l ls-linkto-2" style="top:400px;left:50%;white-space: nowrap;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="images/sliderimages/left.png" alt="">
                            <img class="ls-l ls-linkto-2" style="top:400px;left:52%;white-space: nowrap;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="images/sliderimages/right.png" alt="">
                        </div>
                        <div class="ls-slide" data-ls="transition2d:1;timeshift:-10000;">
                            <img src="images/sliderimages/banner2.jpg" class="ls-bg" alt="Slide background"/>
                            <h3 class="ls-l" style="left:50%; top:150px; padding: 15px; color: #444444;font-size: 24px;font-family: 'Open Sans'; font-weight: bold; text-transform: uppercase;" data-ls="offsetxin:0;durationin:2500;delayin:500;durationout:750;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotateout:-90;transformoriginout:left bottom 0;"></h3>
                            <h1 class="ls-l" style="left: 50%; top:200px;background: #e96969;padding:0 10px; opacity: 1; color: #ffffff; font-size: 36px; font-family: 'Open Sans'; text-transform: uppercase; font-weight: bold;" data-ls="offsetxin:left;durationin:3000; delayin:800;durationout:850;rotatexin:90;rotatexout:-90;"></h1>
                            <p class="ls-l" style="text-align:center; font-weight:600;left:50%; top:265px; opacity: 1;width: 450px; color: #444; font-size: 14px; font-family: 'Open Sans';" data-ls="offsetyin:top;durationin:4000;rotateyin:90;rotateyout:-90;durationout:1050;"></p>
                            <!--<a href="#" class="ls-l button" style="border-radius:4px;text-align:center;left:50%; top:315px;background: #444;color: #ffffff;font-family: 'Open Sans';font-size: 14px;display: inline-block; text-transform: uppercase; font-weight: bold;" data-ls="durationout:850;offsetxin:90;offsetxout:-90;duration:4200;fadein:true;fadeout:true;">Upload Videos</a>-->
                            <img class="ls-l ls-linkto-1" style="top:400px;left:50%;white-space: nowrap;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="images/sliderimages/left.png" alt="">
                            <img class="ls-l ls-linkto-1" style="top:400px;left:52%;white-space: nowrap;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="images/sliderimages/right.png" alt="">
                        </div>
                        <div class="ls-slide" data-ls="transition2d:1;timeshift:-10000;">
                            <img src="images/sliderimages/banner3.jpg" class="ls-bg" alt="Slide background"/>
                            <h3 class="ls-l" style="left:50%; top:150px; padding: 15px; color: #444444;font-size: 24px;font-family: 'Open Sans'; font-weight: bold; text-transform: uppercase;" data-ls="offsetxin:0;durationin:2500;delayin:500;durationout:750;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotateout:-90;transformoriginout:left bottom 0;"></h3>
                            <h1 class="ls-l" style="left: 50%; top:200px;background: #e96969;padding:0 10px; opacity: 1; color: #ffffff; font-size: 36px; font-family: 'Open Sans'; text-transform: uppercase; font-weight: bold;" data-ls="offsetxin:left;durationin:3000; delayin:800;durationout:850;rotatexin:90;rotatexout:-90;"></h1>
                            <p class="ls-l" style="text-align:center; font-weight:600;left:50%; top:265px; opacity: 1;width: 450px; color: #444; font-size: 14px; font-family: 'Open Sans';" data-ls="offsetyin:top;durationin:4000;rotateyin:90;rotateyout:-90;durationout:1050;"> .</p>
                           <!-- <a href="#" class="ls-l button" style="border-radius:4px;text-align:center;left:50%; top:315px;background: #444;color: #ffffff;font-family: 'Open Sans';font-size: 14px;display: inline-block; text-transform: uppercase; font-weight: bold;" data-ls="durationout:850;offsetxin:90;offsetxout:-90;duration:4200;fadein:true;fadeout:true;">Upload Videos</a>-->
                            <img class="ls-l ls-linkto-1" style="top:400px;left:50%;white-space: nowrap;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="images/sliderimages/left.png" alt="">
                            <img class="ls-l ls-linkto-1" style="top:400px;left:52%;white-space: nowrap;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="images/sliderimages/right.png" alt="">
                        </div>
                    </div>
                </div>
            </section><!--end slider-->

            <!-- Premium Videos -->
            <!--<section id="premium">
                <div class="row">
                    <div class="heading clearfix">
                        <div class="large-11 columns">
                            <h4><i class="fa fa-play-circle-o"></i>Premium Videos</h4>
                        </div>
                        <div class="large-1 columns">
                            <div class="navText show-for-large">
                                <a class="prev secondary-button"><i class="fa fa-angle-left"></i></a>
                                <a class="next secondary-button"><i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                 
                <div id="owl-demo" class="owl-carousel carousel" data-car-length="4" data-items="4" data-loop="true" data-nav="false" data-autoplay="true" data-autoplay-timeout="3000" data-dots="false" data-auto-width="false" data-responsive-small="1" data-responsive-medium="2" data-responsive-xlarge="5">
                
               <?php 
				$query = mysqli_query($link,"select * from video_post order by id desc");
				while($row = mysqli_fetch_array($query))
				{
				
				?>
                
                    <div class="item">
                   
                        <figure class="premium-img">
                         
                            <img src="http://img.youtube.com/vi/<?php echo $row['video_url'];?>/0.jpg" alt="carousel">
                            <figcaption>
                                <h5><?php  echo $row['title']?></h5>
                                <p><?php  echo $row['title']?></p>
                            </figcaption>
                        </figure>
                        <a href="single-video-v2.php?video_url=<?php echo $row['video_url']?>" class="hover-posts">
                            <span><i class="fa fa-play"></i>watch video</span>
                        </a>
                        
                    </div>
                    
                     
                   <?php } ?>
                    
                    
                </div>
                
            </section>--><!-- End Premium Videos -->
            <!-- Category -->
            <section id="category">
                <div class="row secBg">
                    <div class="large-12 columns">
                        <div class="column row">
                            <div class="heading category-heading clearfix">
                                <div class="cat-head pull-left">
                                    <i class="fa fa-folder-open"></i>
                                    <h4>Browse Videos By Category</h4>
                                </div>
                                <div>
                                <div class="navText pull-right show-for-large">
                                    <a class="prev secondary-button"><i class="fa fa-angle-left"></i></a>
                                    <a class="next secondary-button"><i class="fa fa-angle-right"></i></a>
                                </div>
                                </div>
                            </div>
                        </div>
                        <!-- category carousel -->
                        <div id="owl-demo-cat" class="owl-carousel carousel" data-car-length="6" data-items="6" data-loop="true" data-nav="false" data-autoplay="true" data-autoplay-timeout="4000" data-auto-width="true" data-margin="10" data-dots="false">
                        
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/nailtheshow.jpg" alt="carousel">
                                    <a href="categories.php?id=Nails Today Show" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=Nails Today Show"> NAILS TODAY SHOW</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/dodi.jpg" alt="carousel">
                                    <a href="categories.php?id=Di Day Di Do" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=Di Day Di Do">ĐI ĐÂY ĐI ĐÓ</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/lifeonwheel.jpg" alt="carousel">
                                    <a href="categories.php?id=LIFE ON WHEELS" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=LIFE ON WHEELS">LIFE ON WHEELS</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/suc.jpg" alt="carousel">
                                    <a href="categories.php?id=Suc Khoe va Cuoc Song" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=Suc Khoe va Cuoc Song">SỨC KHOẺ  SONG</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/nanch.jpg" alt="carousel">
                                    <a href="categories.php" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php">BI QUYET TAI CHINH</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/bobachow.jpg" alt="carousel">
                                    <a href="categories.php?id=Bo Ba Show" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=Bo Ba Show">BO BA SHOW</a></h6>
                            </div>
                            <div class="item-cat item thumb-border">
                                <figure class="premium-img">
                                    <img src="images/celeb.jpg" alt="carousel">
                                    <a href="categories.php?id=celebrities" class="hover-posts">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </figure>
                                <h6><a href="categories.php?id=celebrities">CELEBRITIES</a></h6>
                            </div>
                            
                        </div><!-- end carousel -->
                        <div class="row collapse">
                            <div class="large-12 columns text-center row-btn">
                                <a href="categories.php" class="button radius">View All Categories</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- End Category -->
            <!-- main content -->
            <section class="content">
                <!-- newest video -->
                <div class="main-heading">
                    <div class="row secBg padding-14">
                        <div class="medium-8 small-8 columns">
                            <div class="head-title">
                                <i class="fa fa-film"></i>
                                <h4>Newest Videos</h4>
                            </div>
                        </div>
                        <div class="medium-4 small-4 columns">
                            <ul class="tabs text-right pull-right" data-tabs id="newVideos">
                                <li class="tabs-title is-active"><a href="#new-all">all</a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row secBg">
                    <div class="large-12 columns">
                        <div class="row column head-text clearfix">
                        <?php 
						$totad_videos = mysqli_query($link,"select * from video_post");
						$num_rows = mysqli_num_rows($totad_videos)
						?>
                        
                            <p class="pull-left">All Videos : <span><?php echo $num_rows; ?> Videos posted</span></p>
                            <div class="grid-system pull-right show-for-large">
                                <a class="secondary-button current grid-default" href="#"><i class="fa fa-th"></i></a>
                                <a class="secondary-button grid-medium" href="#"><i class="fa fa-th-large"></i></a>
                                <a class="secondary-button list" href="#"><i class="fa fa-th-list"></i></a>
                            </div>
                        </div>
                        <div class="tabs-content" data-tabs-content="newVideos">
                            <div class="tabs-panel is-active" id="new-all">
                                <div class="row list-group">
                              
                                    <?php 
								$query1 = mysqli_query($link,"select * from video_post ORDER BY `id` DESC limit  12");
								while($roww = mysqli_fetch_array($query1))
								{
								
								
								?>
                                 
                                
                                    <div class="item large-3 medium-6 columns group-item-grid-default">
                                     
                                        <div class="post thumb-border">
                                            <div class="post-thumb">
                                                <img src="http://img.youtube.com/vi/<?php echo $roww['video_url'];?>/0.jpg" alt="new video">
                                                <a href="single-video-v2.php?video_url=<?php echo $roww['video_url']?>" class="hover-posts">
                                                    <span><i class="fa fa-play"></i>Watch Video</span>
                                                </a>
                                                <div class="video-stats clearfix">
                                                    <div class="thumb-stats pull-left">
                                                        <h6>HD</h6>
                                                    </div>
                                                    <div class="thumb-stats pull-left">
                                                        <i class="fa fa-heart"></i>
                                                        <span>506</span>
                                                    </div>
                                                    <div class="thumb-stats pull-right">
                                                        <span>05:56</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-des">
                                                <h6><a href="single-video-v2.php?video_url=<?php echo $roww['video_url']?>"><?php echo $roww['title']; ?>.</a></h6>
                                                <div class="post-stats clearfix">
                                                    
                                                    <p class="pull-left">
                                                        <i class="fa fa-clock-o"></i>
                                                     <?php
													$date=date_create("$roww[date]");
													 $fin = date_format($date,"d F Y");
?>
                                                       
                                                        <span><?php echo $fin; ?></span>
                                                    </p>
                                                    <p class="pull-left">
                                                        <i class="fa fa-eye"></i>
                                                        <span>1,862K</span>
                                                    </p>
                                                </div>
                                                <div class="post-summary">
                                                    <p><?php echo $roww['description']; ?>.</p>
                                                </div>
                                                <div class="post-button">
                                                    <a href="single-video-v2.php?video_url=<?php echo $roww['video_url']?>" class="secondary-button"><i class="fa fa-play-circle"></i>watch video</a>
                                                </div>
                                            </div>
                                        </div>
                                         
                                    </div>
                                    
                                    
                                 
                                      <?php } ?>
                                    
                                    
                                    
                                </div>
                            </div>
                            
                        </div>
                        <div class="text-center row-btn">
                            <a class="button radius" href="all-video.php">View All Video</a>
                        </div>
                    </div>
                </div>
            </section>
            <section class="content">
                <!-- End newest video -->
                <!-- ad Section -->
                <!-- End ad Section -->

                <!-- popular Videos -->
                <div class="main-heading">
                    <div class="row secBg padding-14">
                        <div class="medium-8 small-8 columns">
                            <div class="head-title">
                                <i class="fa fa-star"></i>
                                <h4>Most Popular Videos</h4>
                            </div>
                        </div>
                        <div class="medium-4 small-4 columns">
                            <ul class="tabs text-right pull-right" data-tabs id="popularVideos">
                                <li class="tabs-title is-active"><a href="#popular-all">all</a></li>
                                <li class="tabs-title"><a href="#popular-hd">HD</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row secBg">
                    <div class="large-12 columns">
                        <div class="row column head-text clearfix">
                            <p class="pull-left">All Videos : <span>1,862 Videos posted</span></p>
                            <div class="grid-system pull-right show-for-large">
                                <a class="secondary-button current grid-default" href="#"><i class="fa fa-th"></i></a>
                                <a class="secondary-button grid-medium" href="#"><i class="fa fa-th-large"></i></a>
                                <a class="secondary-button list" href="#"><i class="fa fa-th-list"></i></a>
                            </div>
                        </div>
                        <div class="tabs-content" data-tabs-content="popularVideos">
                            <div class="tabs-panel is-active" id="popular-all">
                                <div class="row list-group">
                                 <?php 
									$popular  = mysqli_query($link,"select * from video_post where sub_category = 'Nails Today Show' order by id desc limit 12");
									while($rowww = mysqli_fetch_array($popular))
									{
									
									?>
                                    <div class="item large-3 medium-6 columns group-item-grid-default">
                                   
                                    
                                        <div class="post thumb-border">
                                            <div class="post-thumb">
                                                <img src="http://img.youtube.com/vi/<?php echo $rowww['video_url'];?>/0.jpg" alt="new video">
                                                <a href="single-video-v2.php?video_url=<?php echo $rowww['video_url']; ?>" class="hover-posts">
                                                    <span><i class="fa fa-play"></i>Watch Video</span>
                                                </a>
                                                <div class="video-stats clearfix">
                                                    <div class="thumb-stats pull-left">
                                                        <h6>HD</h6>
                                                    </div>
                                                    <div class="thumb-stats pull-left">
                                                        <i class="fa fa-heart"></i>
                                                        <span>506</span>
                                                    </div>
                                                    <div class="thumb-stats pull-right">
                                                        <span>05:56</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-des">
                                                <h6><a href="single-video-v2.php"><?php echo $rowww['title'];?></a></h6>
                                                <div class="post-stats clearfix">
                                                    
                                                    <p class="pull-left">
                                                        <i class="fa fa-clock-o"></i><?php
                                                        $date=date_create("$rowww[date]");
													 $fin = date_format($date,"d F Y");
													 ?>
													 
                                                        <span><?php echo $fin; ?></span>
                                                    </p>
                                                    <p class="pull-left">
                                                        <i class="fa fa-eye"></i>
                                                        <span>1,862K</span>
                                                    </p>
                                                </div>
                                                <div class="post-summary">
                                                    <p><?php echo $rowww['description']?>.</p>
                                                </div>
                                                <div class="post-button">
                                                    <a href="single-video-v2.php?video_url=<?php echo $rowww['video_url']?>; ?>" class="secondary-button"><i class="fa fa-play-circle"></i>watch video</a>
                                                </div>
                                            </div>
                                        </div>
                                       
                                        
                                    </div>
                                    
                                    
                                    
                                     <?php } ?>
                                    
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            
                        </div>
                        <div class="text-center row-btn">
                            <a class="button radius" href="all-video.php">View All Video</a>
                        </div>
                    </div>
                </div>
                <!-- ad Section -->
                <!-- End ad Section -->
            </section><!-- End main content -->
            <!-- movies -->
            <!-- End movie -->
            <!-- End ad Section -->
            <!-- footer -->
         <?php include('footer.php');?>