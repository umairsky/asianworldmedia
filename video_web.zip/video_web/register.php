<?php
error_reporting(0);
session_start();
include_once('connection/config.php');



if($_REQUEST['submit'])
{ 

$name = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

$unique_id = uniqid();
	$query = mysqli_query($link,"INSERT INTO `register`(`unique_id`, `username`, `email`, `password`) VALUES ('$unique_id','$name','$email','$password')");
	echo "<script>window.location='login.php?msg=You have successfully registered With us';</script>";  
}


?>


