<?php
error_reporting(0);
session_start();
include('connection/config.php');



?>