<?php
error_reporting(0);
session_start();
include('connection/config.php');


?>

<div class="large-4 columns">
                        <aside class="secBg sidebar">
                            <div class="row">
                                <!-- search Widget -->
                                <div class="large-12 medium-7 medium-centered columns">
                                    <div class="widgetBox">
                                        <div class="widgetTitle">
                                            <h5>Search Videos</h5>
                                        </div>
                                        <form id="searchform" method="get" role="search">
                                            <div class="input-group">
                                                <input class="input-group-field" type="text" placeholder="Enter your keyword">
                                                <div class="input-group-button">
                                                    <input type="submit" class="button" value="Submit">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div><!-- End search Widget -->

                                <!-- categories -->
                                <div class="large-12 medium-7 medium-centered columns">
                                    <div class="widgetBox">
                                        <div class="widgetTitle">
                                            <h5>categories</h5>
                                        </div>
                                        <div class="widgetContent">
                                            <ul class="accordion" data-accordion>
                                                <li class="accordion-item" data-accordion-item>
                                                    <a href="categories.php?cat=Entertaiment" class="accordion-title">Entertainment</a>
                                                    <div class="accordion-content" data-tab-content>
                                                       <ul>
                                                        
                                                           <li class="clearfix">
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Nhan Goi Yeu Thuong (Musix Box)"> NHẮN GỞI YÊU THƯƠNG (MUSIC BOX)</span></a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Cham Cham Cham (Dot Dot Dot)"> CHẤM CHẤM CHẤM (DOT DOT DOT) <span></span></a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=ÂM NHẠC VÀ CUỘC SỐNG">ÂM NHẠC VÀ CUỘC SỐNG <span></span></a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Music Liveshows"> MUSIC LIVESHOWS</a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Nails Today Show">NAILS TODAY SHOW</a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                              <a href="categories.php?id=Bo Ba Show"></i>BỘ BA SHOW</a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Gentleman Life Style">GENTLEMEN LIFE STYLE</a>
                                                           </li>
                                                           <li>
                                                               <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=An Vat ( 50K a Night)">ĂN VẶT (5OK A NIGHT)</a>
                                                           </li>
                                                       </ul>
                                                    </div>
                                                </li>
                                                
                                                <li class="accordion-item" data-accordion-item>
                                                    <a href="categories.php?cat=Travels" class="accordion-title">Travels</a>
                                                    <div class="accordion-content" data-tab-content>
                                                    
                                                        <ul>
                                                            <li class="clearfix">
                                                                <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Thu Gian Cuoi Tuan"><i class=""></i>THƯ GIÃN CUỐI TUẦN</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Viet Nam - Dat Nuoc Toi Yeu"><i class=""></i>VIỆT NAM - ĐẤT NƯỚC TÔI YÊU</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Di Day Di Do"><i class=""></i> ĐI ĐÂY ĐI ĐÓ</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li class="accordion-item" data-accordion-item>
                                                    <a href="categories.php?cat=Drama" class="accordion-title">Drama</a>
                                                    <div class="accordion-content" data-tab-content>
                                                         <ul>
                                                            <li class="clearfix">
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Taiwanese"><i class=""></i>TAIWANESE</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Thai"><i class=""></i>THAI</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Thai"><i class=""></i>VIETNAMESE</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=chinese"><i class=""></i>CHINESE</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li class="accordion-item" data-accordion-item>
                                                    <a href="categories.php?cat=Talk show" class="accordion-title">Talk show</a>
                                                    <div class="accordion-content" data-tab-content>
                                                    
                                                         <ul>
                                                            <li class="clearfix">
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Suc Khoe va Cuoc Song"><i class=""></i>SỨC KHOẺ VÀ CUỘC SỐNG</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Bi Quyet Tai Chinh (Financial Insight)"><i class=""></i>BBÍ QUYẾT TÀI CHÍNH (FINANCIAL INSIGHT)</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="categories.php?id=Cuoc Song Hom Nay ( Mental Health)"><i class=""></i>CUỘC SỐNG HÔM NAY (MENTAL HEALTH)</a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=American Dream"><i class=""></i>AMERICAN DREAM</a>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li class="accordion-item" data-accordion-item>
                                                    <a href="categories.php?cat=Game show" class="accordion-title">Game Show</a>
                                                    <div class="accordion-content" data-tab-content>
                                                         <ul>
                                                            <li class="clearfix">
                                                                <i class="fa fa-play-circle-o"></i>
                                                                <a href="#">Movies <span>(10)</span></a>
                                                            </li>
                                                            <li>
                                                                <i class="fa fa-play-circle-o"></i>
                                                               <a href="categories.php?id=Giai Ma Cap Doi"><i class=""></i>GIẢI MÃ CẶP ĐÔI</a>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div>
                                                </li>
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>



                                <!-- social Fans Widget -->
                                <!--<div class="large-12 medium-7 medium-centered columns">
                                    <div class="widgetBox">
                                        <div class="widgetTitle">
                                            <h5>social fans</h5>
                                        </div>
                                        <div class="widgetContent">
                                            <div class="social-links">
                                                <a class="socialButton" href="#">
                                                    <i class="fa fa-facebook"></i>
                                                    <span>698K</span>
                                                    <span>fans</span>
                                                </a>
                                                
                                               
                                                <a class="socialButton" href="#">
                                                    <i class="fa fa-youtube"></i>
                                                    <span>168k</span>
                                                    <span>followers</span>
                                                </a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>--><!-- End social Fans Widget -->

                                <!-- slide video -->
                                <div class="large-12 medium-7 medium-centered columns">
                                    <section class="widgetBox">
                                        <div class="row">
                                            <div class="large-12 columns">
                                                <div class="column row">
                                                    <div class="heading category-heading clearfix">
                                                        <div class="cat-head pull-left">
                                                            <h4>slide videos</h4>
                                                        </div>
                                                        <div class="sidebar-video-nav">
                                                            <div class="navText pull-right">
                                                                <a class="prev secondary-button"><i class="fa fa-angle-left"></i></a>
                                                                <a class="next secondary-button"><i class="fa fa-angle-right"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- slide Videos-->
                                                <div id="owl-demo-video" class="owl-carousel carousel" data-car-length="1" data-items="1" data-loop="true" data-nav="false" data-autoplay="true" data-autoplay-timeout="3000" data-dots="false">
                                                    

                                                    <?php 
													$query = mysqli_query($link,"select * from video_post order by id desc limit 3");
													while($row=mysqli_fetch_array($query))
													{
													
													
													?>

                                                    <div class="item item-video thumb-border">
                                                        <figure class="premium-img">
                                                            <img src="http://img.youtube.com/vi/<?php echo $row['video_url'];?>/0.jpg" alt="carousel">
                                                            <a href="single-video-v2.php?video_url=<?php echo $row['video_url']?>" class="hover-posts">
                                                                <span><i class="fa fa-play"></i></span>
                                                            </a>
                                                        </figure>
                                                        <div class="video-des">
                                                            <h6><a href="single-video-v2.php?video_url=<?php echo $row['video_url']?>"><?php echo $row['title']?></a></h6>
                                                            <div class="post-stats clearfix">
                                                                
                                                                <p class="pull-left">
                                                                    <i class="fa fa-clock-o"></i>
                                                                    
                                                                    <?php 
																	$date=date_create("$row[date]");
													 				$fin = date_format($date,"d F Y");
																	
																	?>
                                                                    <span><?php echo $fin; ?></span>
                                                                </p>
                                                                <p class="pull-left">
                                                                    <i class="fa fa-eye"></i>
                                                                    <span>1,862K</span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <?php } ?>

                                                </div><!-- end carousel -->
                                            </div>
                                        </div>
                                    </section><!-- End Category -->
                                </div><!-- End slide video -->

                                <!-- ad banner widget -->
                                <!-- end ad banner widget -->

                                <!-- Recent post videos -->
                                <!-- End Recent post videos -->

                                <!-- tags -->
                                <!-- End tags -->

                                <!--news letter-->
                                <div class="large-12 medium-7 medium-centered columns">
                                    <div class="widgetBox">
                                        <div class="newsLetter">
                                            <h3>Newsletter Singup</h3>
                                            <p>Subscribe to get exclusive videos</p>
                                            <form method="post">
                                                <div class="input-group">
                                                    <input class="input-group-field" type="email" placeholder="Enter your email addres">
                                                    <div class="input-group-button">
                                                        <input type="submit" class="button" value="Signup">
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div><!--End news letter-->

                                <!-- twitter -->
                                <!-- End Twitter -->

                            </div>
                        </aside>
                    </div>