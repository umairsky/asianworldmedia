<?php
error_reporting(0);
session_start();
include('connection/config.php');

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asian World Media</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="layerslider/css/layerslider.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery.kyco.easyshare.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <script language="javascript">
	function change_cat()
{
	var category_main = document.stform.category_main.value;
	var sub_category = document.stform.sub_category;
	var ixandx = document.getElementById("ixandx");
	var xiandxii = document.getElementById("xiandxii");

	switch(category_main)
	{
		
	  case 'Entertaiment' : sub_category.innerHTML="<option value=''> Select Sub-Category </option><option value='Nhan Goi Yeu Thuong (Musix Box)'>Nhan Goi Yeu Thuong (Musix Box)</option><option value='Cham Cham Cham (Dot Dot Dot)'>Cham Cham Cham (Dot Dot Dot)</option><option value='Am Nhac Va Cuoc Song'>Am Nhac Va Cuoc Song</option><option value='Music Liveshows'>Music Liveshows</option><option value='Nails Today Show'>Nails Today Show</option><option value='Bo Ba Show'>Bo Ba Show</option><option value='Gentleman Life Style'>Gentleman Life Style</option><option value='An Vat ( 50K a Night)'>An Vat ( 50K a Night)</option>";
	  break;

	 case 'Travels' : sub_category.innerHTML="<option value=''> Select Sub-Category </option><option value='Thu Gian Cuoi Tuan'>Thu Gian Cuoi Tuan</option><option value='Viet Nam - Dat Nuoc Toi Yeu'>Viet Nam - Dat Nuoc Toi Yeu</option><option value='LIFE ON WHEELS'>LIFE ON WHEELS</option><option value='Di Day Di Do'>Di Day Di Do</option>";				  
	  break;


	   case 'Drama':sub_category.innerHTML="<option value=''> Select Sub-Category </option><option value='Taiwanese'>Taiwanese</option><option value='Thai'>Thai</option><option value='Vietnamese'>Vietnamese</option><option value='Chinese'>Chinese</option>";
						  
	  break;
	   
	   case 'Talk Show':sub_category.innerHTML="<option value=''> Select Sub-Category </option><option value='Suc Khoe va Cuoc Song'>Suc Khoe va Cuoc Song</option><option value='Bi Quyet Tai Chinh (Financial Insight)'>Bi Quyet Tai Chinh (Financial Insight)</option><option value='Cuoc Song Hom Nay ( Mental Health)'>Cuoc Song Hom Nay ( Mental Health)</option><option value='American Dream'>American Dream</option>";
						  
	  break;
	  case 'Game Show':sub_category.innerHTML="<option value=''> Select Sub-Category </option><option value='Giai Ma Cap Doi'>Giai Ma Cap Doi</option><";
						  
	  break;


	  default : sub_category.innerHTML="<option value=''> Select Sub-Category </option>";
	}
}
	</script>
</head>
<body>
<div class="off-canvas-wrapper">
    <div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
        <!--header-->
        
        <div class="off-canvas-content" data-off-canvas-content>
            <?php include('header.php');?><!-- End Header -->
            <!--breadcrumbs-->
            <section id="breadcrumb">
                <div class="row">
                    <div class="large-12 columns">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs">
                                <li><i class="fa fa-home"></i><a href="#">Home</a></li>
                                <li><a href="#" >profile</a></li>
                                <li>
                                    <span class="show-for-sr">Current: </span> submit post
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </section><!--end breadcrumbs-->

            <!-- profile top section -->
            <section class="topProfile topProfile-inner" style="background: url('images/profile-bg1.png') no-repeat;">
                <div class="main-text">
                    <div class="row">
                        <div class="large-12 columns">
                            <h3>World's Biggest</h3>
                            <h1>Powerfull Video Website</h1>
                        </div>
                    </div>
                </div>
                <div class="profile-stats">
                    <div class="row secBg">
                        <div class="large-12 columns">
                            <div class="profile-author-img">
                                <img src="http://placehold.it/120x110" alt="profile author img">
                            </div>
                            <div class="profile-subscribe">
                                <span><i class="fa fa-users"></i>6</span>
                                <button type="submit" name="subscribe">subscribe</button>
                            </div>
                            <div class="profile-share">
                                <div class="easy-share" data-easyshare data-easyshare-http data-easyshare-url="http://joinwebs.com">
                                    <!-- Facebook -->
                                    <button data-easyshare-button="facebook">
                                        <span class="fa fa-facebook"></span>
                                        <span>Share</span>
                                    </button>
                                    <span data-easyshare-button-count="facebook">0</span>

                                    <!-- Twitter -->
                                    <button data-easyshare-button="twitter" data-easyshare-tweet-text="">
                                        <span class="fa fa-twitter"></span>
                                        <span>Tweet</span>
                                    </button>
                                    <span data-easyshare-button-count="twitter">0</span>

                                    <!-- Google+ -->
                                    <button data-easyshare-button="google">
                                        <span class="fa fa-google-plus"></span>
                                        <span>+1</span>
                                    </button>
                                    <span data-easyshare-button-count="google">0</span>

                                    <div data-easyshare-loader>Loading...</div>
                                </div>
                            </div>
                            <div class="clearfix">
                                <div class="profile-author-name float-left">
                                    <h4>Joseph John</h4>
                                    <p>Join Date : <span>5 January 16</span></p>
                                </div>
                                <div class="profile-author-stats float-right">
                                    <ul class="menu">
                                        <li>
                                            <div class="icon float-left">
                                                <i class="fa fa-video-camera"></i>
                                            </div>
                                            <div class="li-text float-left">
                                                <p class="number-text">36</p>
                                                <span>Videos</span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon float-left">
                                                <i class="fa fa-heart"></i>
                                            </div>
                                            <div class="li-text float-left">
                                                <p class="number-text">50</p>
                                                <span>favorites</span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon float-left">
                                                <i class="fa fa-users"></i>
                                            </div>
                                            <div class="li-text float-left">
                                                <p class="number-text">6</p>
                                                <span>followers</span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon float-left">
                                                <i class="fa fa-comments-o"></i>
                                            </div>
                                            <div class="li-text float-left">
                                                <p class="number-text">26</p>
                                                <span>comments</span>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- End profile top section -->
            <div class="row">
                <!-- left sidebar -->
                <div class="large-4 columns">
                    <aside class="secBg sidebar">
                        <div class="row">
                            <!-- profile overview -->
                            <div class="large-12 columns">
                                <?php include('profile_left.php'); ?>
                            </div><!-- End profile overview -->
                        </div>
                    </aside>
                </div><!-- end sidebar -->
                <!-- right side content area -->
                <div class="large-8 columns profile-inner">
                    <!-- profile settings -->
                    <section class="submit-post">
                        <div class="row secBg">
                            <div class="large-12 columns">
                                <div class="heading">
                                    <i class="fa fa-pencil-square-o"></i>
                                    <h4>Add new video Post</h4>
                                </div>
                                <div class="row">
                                    <div class="large-12 columns">

                                        <form  name="stform" id="stform" action="submit_video.php" enctype="multipart/form-data" method="post">
                                            <div data-abide-error class="alert callout" style="display: none;">
                                                <p><i class="fa fa-exclamation-triangle"></i>
                                                    There are some errors in your form.</p>
                                            </div>
                                            <div class="row">
                                                <div class="large-12 columns">
                                                    <label>Title
                                                        <input type="text" placeholder="enter you video title..." required name="title">
                                                        <span class="form-error">
                                                            Yo, you had better fill this out, it's required.
                                                        </span>
                                                    </label>
                                                </div>
                                                <div class="large-12 columns">
                                                    <label  tsr>Description
                                                        <textarea name="description"></textarea>
                                                    </label>
                                                </div>
                                                
                                                
                                                <div class="large-12 columns">
                                                    <label>Put here your video id here like embed/<strong>t4OrDdOWUpc</strong>
                                                        <input type="text" placeholder="t4OrDdOWUpc" name="video_url">
                                                    </label>
                                                   
                                                </div>
                                                <div class="large-12 columns">
                                                    <div class="post-meta">
                                                        <label>Meta Title:
                                                            <textarea placeholder="enter meta title" name="meta_title"></textarea>
                                                        </label>
                                                        <p>IF you want to put your custom meta Title then put here otherwise your post title will be the default meta Title</p>
                                                    </div>
                                                    <div class="post-meta">
                                                        <label>Meta Description:
                                                            <textarea placeholder="enter meta Description" name="meta_desc"></textarea>
                                                        </label>
                                                        <p>IF you want to put your custom meta description then put here otherwise your post description will be the default meta description</p>
                                                    </div>
                                                    <div class="post-meta">
                                                        <label>Meta keywords:
                                                            <textarea placeholder="enter meta keywords" name="meta_keyword"></textarea>
                                                        </label>
                                                        <p>IF you want to put your custom meta Keywords then put here otherwise your post Keywords will be the default meta Keywords</p>
                                                    </div>
                                                    <div class="post-category">
                                                        <label>Choose Video Category:
                                                            <select  name="category_main" id="category_main"  onChange="change_cat()" required>
                                                            <option value="">Select Category</option>
                                                                <option value="Entertaiment">Entertaiment</option>
                                                                <option value="Travels">Travels</option>
                                                                <option value="Drama">Drama</option>
                                                                <option value="Talk Show">Talk Show</option>
                                                                <option value="Game Show">Game Show</option>
                                                            </select>
                                                        </label>
                                                    </div>
                                                    <div class="post-category" id="ixandx">
                                                        <label>Choose Sub Category:
                                                            <select  name="sub_category" id="sub_category">
                                                                <option value="">--Select--</option>
                                                            </select>
                                                        </label>
                                                    </div>
                                                    
                                                      
                                                    <div class="upload-video">
                                                        <label for="imgUpload" class="button">Upload Image</label>
                                                        <input type="file" id="imgUpload" class="show-for-sr" name="image">
                                                        
                                                    </div>
                                                </div>
                                                
                                                
                                                <div class="large-12 columns">
                                                    <input type="submit" class="button expanded" value="Publish"  name="submit">
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </section><!-- End profile settings -->
                </div><!-- end left side content area -->
            </div>

            <!-- footer -->
           <?php include('footer.php');?>