<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asian World Media</title>
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="layerslider/css/layerslider.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery.kyco.easyshare.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<div class="off-canvas-wrapper">
    <div class="off-canvas-wrapper-inner" data-off-canvas-wrapper>
        <!--header-->
        
        <div class="off-canvas-content" data-off-canvas-content>
            <?php include('header.php');?><!-- End Header -->
            <!--breadcrumbs-->
            <section id="breadcrumb">
                <div class="row">
                    <div class="large-12 columns">
                        <nav aria-label="You are here:" role="navigation">
                            <ul class="breadcrumbs">
                                <li><i class="fa fa-home"></i><a href="#">Home</a></li>
                                <li>
                                    <span class="show-for-sr">Current: </span> contact us
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </section><!--end breadcrumbs-->

            <!-- registration -->
            <section class="registration">
                <div class="row secBg">
                    <div class="large-12 columns">
                        <div class="login-register-content">
                            <div class="row collapse borderBottom">
                                <div class="medium-6 large-centered medium-centered">
                                    <div class="page-heading text-center">
                                        <h3>Contact Us</h3>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="row" data-equalizer data-equalize-on="medium" id="test-eq">
                                <div class="large-6 columns">
                                    <h4><strong>Contact Information</strong>:</h4>
                                    <div class="map">
                                        <img src="http://placehold.it/570x300" alt="map">
                                    </div>
                                    <div class="user-contacts">
                                        <div class="row">
                                            <div class="large-6 medium-6 columns">
                                                <div class="contact-stats">
                                                    <i class="fa fa-map-marker"></i>
                                                    <h6>Office Adrress</h6>
                                                    <p>7171 Fenwick Lane Westminster, CA 92683</p>
                                                </div>
                                            </div>
                                            <div class="large-6 medium-6 columns">
                                                <div class="contact-stats">
                                                    <i class="fa fa-envelope"></i>
                                                    <h6>Email Adrress</h6>
                                                    <p>INFO@ASIANWORLDMEDIA.COM <br/> Website:  www.ASIANWORLDMEDIA.com </p>
                                                </div>
                                            </div>
                                            <div class="large-6 medium-6 columns">
                                                <div class="contact-stats">
                                                    <i class="fa fa-phone"></i>
                                                    <h6>Phone Numbers</h6>
                                                    <p><strong>Office No :</strong> Toll Free: 1-888-886- 8306 <br/> <strong> </p>
                                                </div>
                                            </div>
                                            <div class="large-6 medium-6 columns">
                                                <div class="contact-stats">
                                                    <i class="fa fa-phone"></i>
                                                    <h6>Social Media</h6>
                                                    <p>
                                                        <a href="#" class="secondary-button"><i class="fa fa-facebook"></i></a>
                                                        <a href="#" class="secondary-button"><i class="fa fa-twitter"></i></a>
                                                        <a href="#" class="secondary-button"><i class="fa fa-google-plus"></i></a>
                                                        <a href="#" class="secondary-button"><i class="fa fa-instagram"></i></a>
                                                        <a href="#" class="secondary-button"><i class="fa fa-vimeo"></i></a>
                                                        <a href="#" class="secondary-button"><i class="fa fa-youtube"></i></a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="large-6 columns">
                                    <h4>We'd Love to hear from you!</h4>
                                    <div class="register-form">
                                    <form method="post" data-abide novalidate>
                                        <div data-abide-error class="alert callout" style="display: none;">
                                            <p><i class="fa fa-exclamation-triangle"></i> There are some errors in your form.</p>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-label"><i class="fa fa-user"></i></span>
                                            <input class="input-group-field" type="text" placeholder="Enter your name" required>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-label"><i class="fa fa-envelope"></i></span>
                                            <input class="input-group-field" type="email" placeholder="Enter your email" required>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-label"><i class="fa fa-book"></i></span>
                                            <input class="input-group-field" type="text" placeholder="Enter your subject" required>
                                        </div>
                                        <textarea required placeholder="Your message"></textarea>
                                        <button class="button expanded" type="submit" name="submit">register Now</button>
                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- footer -->
  <?php include('footer.php')?>