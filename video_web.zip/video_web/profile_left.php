<div class="widgetBox">
                                    <div class="widgetTitle">
                                        <h5>Profile Overview</h5>
                                    </div>
                                    <div class="widgetContent">
                                        <ul class="profile-overview">
                                            <li class="clearfix"><a href="profile-about-me.php"><i class="fa fa-user"></i>about me</a></li>
                                            <li class="clearfix"><a href="profile-video.php"><i class="fa fa-video-camera"></i>Videos <span class="float-right">36</span></a></li>
                                            <li class="clearfix"><a href="profile-favorite.php"><i class="fa fa-heart"></i>Favorite Videos<span class="float-right">50</span></a></li>
                                           
                                            <li class="clearfix"><a href="profile-settings.php"><i class="fa fa-gears"></i>Profile Settings</a></li>
                                            <li class="clearfix"><a href="index.php"><i class="fa fa-sign-out"></i>Logout</a></li>
                                        </ul>
                                        <a href="submit-post.php" class="button"><i class="fa fa-plus-circle"></i>Submit Video</a>
                                    </div>
                                </div>